<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Teacher;
use App\Models\Student;
use App\Models\Agent;
use App\Services\OTPService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    protected $otpService;
    protected $notificationService;

    public function __construct(OTPService $otpService, \App\Services\NotificationService $notificationService)
    {
        $this->otpService = $otpService;
        $this->notificationService = $notificationService;
    }

    public function sendOTP(Request $request)
    {
        $validator = Validator::make($request->all(), [
            "phone" => "required|string|min:10|max:15",
        ]);

        if ($validator->fails()) {
            return response()->json(["errors" => $validator->errors()], 422);
        }

        $result = $this->otpService->sendOTP($request->phone);
        
        return response()->json([
            "message" => "OTP sent successfully",
            "phone" => $request->phone,
            "dev_otp" => config("app.debug") ? "Check logs" : null
        ]);
    }

    public function verifyOTP(Request $request)
    {
        $validator = Validator::make($request->all(), [
            "phone" => "required|string",
            "otp" => "required|string|size:6",
        ]);

        if ($validator->fails()) {
            return response()->json(["errors" => $validator->errors()], 422);
        }

        $verification = $this->otpService->verifyOTP($request->phone, $request->otp);

        if ($verification['success']) {
            $user = User::where("phone", $request->phone)->first();
            
            if (!$user) {
                return response()->json([
                    "message" => "Phone verified",
                    "is_new_user" => true,
                    "phone" => $request->phone
                ]);
            }

            // Revoke current tokens and create new one
            $user->tokens()->delete();
            $token = $user->createToken("auth_token")->plainTextToken;

            return response()->json([
                "message" => "Login successful",
                "is_new_user" => false,
                "token" => $token,
                "user" => $user
            ]);
        }

        return response()->json(["message" => $verification['message'] ?? "Invalid or expired OTP"], 401);
    }

    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'phone' => 'required|string|unique:users,phone',
            'role' => 'required|in:teacher,student,parent,agent',
            'email' => 'nullable|email|unique:users,email',
            'referred_by' => 'nullable|string',
            'area_id' => 'required_without:custom_area|nullable|exists:areas,id',
            'custom_area' => 'required_without:area_id|nullable|string|max:255',
            // Detailed teacher fields
            'whatsapp_number' => 'required_if:role,teacher|string',
            'bio' => 'nullable|string',
            'subjects' => 'nullable|array',
            'classes' => 'nullable|array',
            'qualifications' => 'nullable|array',
            'experience_years' => 'nullable|numeric',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $referralId = null;
        if ($request->referred_by) {
            $referrer = Agent::where('referral_code', $request->referred_by)->first();
            $referralId = $referrer ? $referrer->user_id : null;
        }

        // Default status is pending (as requested by user)
        $user = User::create([
            'name' => $request->name,
            'phone' => $request->phone,
            'role' => $request->role,
            'email' => $request->email,
            'status' => 'pending',
            'referred_by' => $referralId,
        ]);

        // Create role-specific profile
        if ($request->role === 'teacher') {
            $teacher = Teacher::create([
                'user_id' => $user->id,
                'whatsapp_number' => $request->whatsapp_number,
                'area_id' => $request->area_id,
                'custom_area' => $request->custom_area,
                'bio' => $request->bio,
                'subjects' => $request->subjects ?? [],
                'classes' => $request->classes ?? [],
                'qualifications' => $request->qualifications ?? [],
                'experience_years' => $request->experience_years ?? 0,
                'city' => 'Lucknow',
                'state' => 'Uttar Pradesh',
            ]);

            // Notify Admin via Email
            $adminEmail = config('mail.from.address'); // Or a specific admin email
            $this->notificationService->sendEmail(
                $adminEmail, 
                "New Teacher Registration: {$user->name}",
                'emails.admin_new_teacher',
                [
                    'name' => $user->name,
                    'phone' => $user->phone,
                    'whatsapp' => $request->whatsapp_number,
                    'email' => $user->email ?? 'N/A'
                ]
            );

            // Notify Teacher via WhatsApp
            $this->notificationService->sendWhatsAppMessage(
                $request->whatsapp_number,
                "Hello {$user->name}, thank you for registering as a teacher. Your account is currently under review. We will notify you once approved."
            );

            // Notify Teacher via Email if provided
            if ($user->email) {
                $this->notificationService->sendEmail(
                    $user->email,
                    'Registration Received',
                    'emails.teacher_registration',
                    ['name' => $user->name]
                );
            }

        } elseif ($request->role === 'student' || $request->role === 'parent') {
            Student::create(['user_id' => $user->id]);
        } elseif ($request->role === 'agent') {
            Agent::create([
                'user_id' => $user->id, 
                'referral_code' => 'AGT' . strtoupper(substr(uniqid(), -6))
            ]);
        }

        $token = $user->createToken('auth_token')->plainTextToken;

        return response()->json([
            'message' => 'Registration successful. Your account is awaiting admin approval.',
            'token' => $token,
            'user' => $user
        ], 201);
    }

    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();
        return response()->json(['message' => 'Logged out successfully']);
    }
}
