<?php

use App\Http\Controllers\Web\AdminController;
use App\Http\Controllers\Web\BannerController;
use App\Http\Controllers\Web\WebAuthController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('landing');
});

// Web Authentication
Route::get('/login', [WebAuthController::class, 'showLogin'])->name('login');
Route::post('/login', [WebAuthController::class, 'login']);
Route::post('/logout', [WebAuthController::class, 'logout'])->name('logout');

// Admin Panel
Route::middleware(['auth', 'role:admin'])->prefix('admin')->group(function () {
    Route::get('/dashboard', [AdminController::class, 'index'])->name('admin.dashboard');
    Route::get('/teachers', [AdminController::class, 'teachers'])->name('admin.teachers');
    Route::get('/students', [AdminController::class, 'students'])->name('admin.students');
    Route::get('/agents', [AdminController::class, 'agents'])->name('admin.agents');
    Route::get('/leads', [AdminController::class, 'leads'])->name('admin.leads');
    Route::get('/attendance', [AdminController::class, 'attendance'])->name('admin.attendance');
    Route::get('/notifications', [AdminController::class, 'notifications'])->name('admin.notifications');
    Route::post('/notifications/send', [AdminController::class, 'sendNotification'])->name('admin.notifications.send');
    Route::get('/tests', [AdminController::class, 'tests'])->name('admin.tests');
    Route::get('/demo-classes', [AdminController::class, 'demoClasses'])->name('admin.demo');
    Route::get('/payments', [AdminController::class, 'payments'])->name('admin.payments');
    Route::post('/payments/{id}/update', [AdminController::class, 'updatePayoutStatus'])->name('admin.payments.update');
    Route::get('/transactions', [AdminController::class, 'transactions'])->name('admin.transactions');
    Route::get('/settings', [AdminController::class, 'settings'])->name('admin.settings');
    Route::post('/settings/update', [AdminController::class, 'updateSettings'])->name('admin.settings.update');
    Route::get('/system-settings', [AdminController::class, 'systemSettings'])->name('admin.system_settings');
    Route::post('/system-settings/update', [AdminController::class, 'updateSystemSettings'])->name('admin.system_settings.update');
    Route::post('/teachers/{id}/verify', [AdminController::class, 'verifyTeacher'])->name('admin.teachers.verify');
    Route::post('/agents/{id}/verify', [AdminController::class, 'verifyAgent'])->name('admin.agents.verify');
    Route::get('/users/create', [AdminController::class, 'createUser'])->name('admin.users.create');
    Route::post('/users', [AdminController::class, 'storeUser'])->name('admin.users.store');
    Route::get('/teachers/{id}', [AdminController::class, 'teacherDetail'])->name('admin.teachers.show');
    Route::get('/students/{id}', [AdminController::class, 'studentDetail'])->name('admin.students.show');
    Route::post('/leads/{id}/toggle-contact', [AdminController::class, 'toggleLeadContact'])->name('admin.leads.toggle_contact');
    Route::post('/leads/{id}/convert', [AdminController::class, 'convertLeadToTuition'])->name('admin.leads.convert');
    
    // Test Notifications
    Route::post('/test-whatsapp', [AdminController::class, 'testWhatsApp'])->name('admin.test-whatsapp');
    Route::post('/test-sms', [AdminController::class, 'testSMS'])->name('admin.test-sms');
    Route::post('/test-email', [AdminController::class, 'testEmail'])->name('admin.test-email');
    
    // Banner Management
    Route::resource('banners', BannerController::class)->names([
        'index' => 'admin.banners.index',
        'create' => 'admin.banners.create',
        'store' => 'admin.banners.store',
        'edit' => 'admin.banners.edit',
        'update' => 'admin.banners.update',
        'destroy' => 'admin.banners.destroy',
    ]);
    Route::patch('/banners/{banner}/toggle', [BannerController::class, 'toggleStatus'])->name('admin.banners.toggle');
});
