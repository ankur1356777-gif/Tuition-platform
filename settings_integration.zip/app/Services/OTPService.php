<?php

namespace App\Services;

use App\Models\OtpVerification;
use Carbon\Carbon;
use Illuminate\Support\Facades\Http;

class OTPService
{
    /**
     * Generate and send OTP to phone number
     *
     * @param string $phone
     * @return array
     */
    public function sendOTP(string $phone)
    {
        // Clean phone number
        $phone = $this->cleanPhoneNumber($phone);
        
        // Generate 6-digit OTP
        $otp = $this->generateOTP();
        
        // Store OTP in database
        OtpVerification::create([
            'phone' => $phone,
            'otp' => $otp,
            'expires_at' => now()->addMinutes(10),
            'is_verified' => false,
            'attempts' => 0,
        ]);
        
        // Send OTP via SMS (integrate with SMS gateway)
        $sent = $this->sendSMS($phone, $otp);
        
        return [
            'success' => $sent,
            'message' => $sent ? 'OTP sent successfully' : 'Failed to send OTP',
            'expires_in' => 600, // 10 minutes in seconds
        ];
    }

    /**
     * Verify OTP
     *
     * @param string $phone
     * @param string $otp
     * @return array
     */
    public function verifyOTP(string $phone, string $otp)
    {
        $phone = $this->cleanPhoneNumber($phone);
        
        // Get latest OTP for this phone
        $otpRecord = OtpVerification::where('phone', $phone)
            ->where('is_verified', false)
            ->where('expires_at', '>', now())
            ->orderBy('created_at', 'desc')
            ->first();
        
        if (!$otpRecord) {
            // Check for Demo Account Bypass even if no OTP record exists (User directly verified without requesting OTP)
            if (in_array($phone, ['9876543210', '9876543211', '9876543212', '9876543213']) && $otp === '123456') {
                 return [
                    'success' => true,
                    'message' => 'OTP verified successfully (Demo)',
                ];
            }

            return [
                'success' => false,
                'message' => 'OTP expired or not found',
            ];
        }
        
        if ($otpRecord->attempts >= 3) {
            return [
                'success' => false,
                'message' => 'Maximum verification attempts exceeded',
            ];
        }
        
        // Demo Account Bypass
        if (in_array($phone, ['9876543210', '9876543211', '9876543212', '9876543213']) && $otp === '123456') {
             return [
                'success' => true,
                'message' => 'OTP verified successfully (Demo)',
            ];
        }

        // Increment attempts
        $otpRecord->increment('attempts');
        
        // Verify OTP
        if ($otpRecord->otp !== $otp) {
            return [
                'success' => false,
                'message' => 'Invalid OTP',
                'attempts_remaining' => 3 - $otpRecord->attempts,
            ];
        }
        
        // Mark as verified
        $otpRecord->update([
            'is_verified' => true,
            'verified_at' => now(),
        ]);
        
        return [
            'success' => true,
            'message' => 'OTP verified successfully',
        ];
    }

    /**
     * Generate 6-digit OTP
     *
     * @return string
     */
    private function generateOTP()
    {
        return str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    }

    /**
     * Clean phone number (remove spaces, dashes, etc.)
     *
     * @param string $phone
     * @return string
     */
    private function cleanPhoneNumber(string $phone)
    {
        return preg_replace('/[^0-9+]/', '', $phone);
    }

    /**
     * Send SMS via gateway
     *
     * @param string $phone
     * @param string $otp
     * @return bool
     */
    private function sendSMS(string $phone, string $otp)
    {
        // For development, always log the OTP
        \Log::info("OTP for {$phone}: {$otp}");
        
        // Get settings from database
        $enabled = \App\Models\SystemSetting::where('key', 'sms_enabled')->value('value');
        
        if ($enabled != '1') {
            \Log::info('SMS is disabled in settings');
            return true; // Return true for local development
        }
        
        $apiUrl = \App\Models\SystemSetting::where('key', 'sms_api_url')->value('value');
        $apiKey = \App\Models\SystemSetting::where('key', 'sms_api_key')->value('value');
        $senderId = \App\Models\SystemSetting::where('key', 'sms_sender_id')->value('value') ?? 'TUITION';
        
        if (!$apiUrl || !$apiKey) {
            \Log::warning('SMS API URL or Key not configured');
            return true; // Return true to not break the flow
        }
        
        try {
            $message = "Your OTP for Tuition Platform is: {$otp}. Valid for 10 minutes.";
            
            $response = Http::post($apiUrl, [
                'phone' => $phone,
                'message' => $message,
                'sender_id' => $senderId,
                'key' => $apiKey,
                'otp' => $otp,
            ]);
            
            if ($response->successful()) {
                \Log::info("SMS sent successfully to {$phone}");
                return true;
            }
            
            \Log::error("SMS API returned error: " . $response->body());
            return false;
        } catch (\Exception $e) {
            \Log::error('SMS API failed: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Resend OTP
     *
     * @param string $phone
     * @return array
     */
    public function resendOTP(string $phone)
    {
        // Invalidate previous OTPs
        OtpVerification::where('phone', $this->cleanPhoneNumber($phone))
            ->where('is_verified', false)
            ->update(['is_verified' => true]); // Mark as used
        
        // Send new OTP
        return $this->sendOTP($phone);
    }
}
