<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

// Authentication Routes
Route::prefix("auth")->group(function () {
    Route::post("/send-otp", [App\Http\Controllers\Api\AuthController::class, "sendOTP"]);
    Route::post("/verify-otp", [App\Http\Controllers\Api\AuthController::class, "verifyOTP"]);
    Route::post("/register", [App\Http\Controllers\Api\AuthController::class, "register"]);
});

// Protected Routes
Route::middleware("auth:sanctum")->group(function () {
    Route::post("/logout", [App\Http\Controllers\Api\AuthController::class, "logout"]);
    
    Route::prefix("profile")->group(function () {
        Route::get("/", [App\Http\Controllers\Api\ProfileController::class, "show"]);
        Route::post("/", [App\Http\Controllers\Api\ProfileController::class, "update"]);
        Route::post("/teacher", [App\Http\Controllers\Api\ProfileController::class, "updateTeacherProfile"]);
    });

    Route::get("/user", function (Request $request) {
        return $request->user();
    });

    // Admin Mobile APIs
    Route::middleware("role:admin")->prefix("admin")->group(function () {
        Route::get("/dashboard", [App\Http\Controllers\Api\AdminApiController::class, "dashboard"]);
        Route::post("/users/{id}/status", [App\Http\Controllers\Api\AdminApiController::class, "manageUserStatus"]);
        Route::get("/leads", [App\Http\Controllers\Api\AdminApiController::class, "leadsOverview"]);
        Route::get("/payouts", [App\Http\Controllers\Api\AdminApiController::class, "payoutRequests"]);
        Route::post("/payouts/{id}/approve", [App\Http\Controllers\Api\AdminApiController::class, "approvePayout"]);
    });

    // Teacher APIs
    Route::middleware("role:teacher")->prefix("teacher")->group(function () {
        Route::get("/dashboard", [App\Http\Controllers\Api\TeacherController::class, "dashboard"]);
        Route::post("/leads/{id}/manage", [App\Http\Controllers\Api\TeacherController::class, "manageLeads"]);
        Route::post("/attendance", [App\Http\Controllers\Api\TeacherController::class, "markAttendance"]);
        Route::post("/tests", [App\Http\Controllers\Api\TeacherController::class, "createTest"]);
        Route::get("/demos", [App\Http\Controllers\Api\TeacherController::class, "demoClasses"]);
        Route::get("/wallet", [App\Http\Controllers\Api\TeacherController::class, "walletHistory"]);
    });

    // Student/Parent APIs
    Route::middleware("role:student")->prefix("student")->group(function () {
        Route::get("/dashboard", [App\Http\Controllers\Api\StudentController::class, "dashboard"]);
        Route::post("/requests", [App\Http\Controllers\Api\StudentController::class, "createRequest"]);
        Route::get("/attendance", [App\Http\Controllers\Api\StudentController::class, "viewAttendance"]);
        Route::get("/test-results", [App\Http\Controllers\Api\StudentController::class, "viewTestResults"]);
    });

    // Agent APIs
    Route::middleware("role:agent")->prefix("agent")->group(function () {
        Route::get("/dashboard", [App\Http\Controllers\Api\AgentController::class, "dashboard"]);
        Route::get("/referrals", [App\Http\Controllers\Api\AgentController::class, "referrals"]);
        Route::get("/wallet", [App\Http\Controllers\Api\AgentController::class, "walletHistory"]);
    });

    // Notifications
    Route::prefix("notifications")->group(function () {
        Route::get("/", [App\Http\Controllers\Api\NotificationController::class, "index"]);
        Route::post("/{id}/read", [App\Http\Controllers\Api\NotificationController::class, "markAsRead"]);
        Route::post("/tokens", [App\Http\Controllers\Api\NotificationController::class, "registerToken"]);
    });
});
