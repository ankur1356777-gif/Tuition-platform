<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PublicController extends Controller
{
    public function getLandingData()
    {
        $banners = \App\Models\Banner::where('is_active', true)->orderBy('order')->get();
        // Publicly visible teachers
        $teachers = \App\Models\Teacher::with('user')
            ->where('is_active', true)
            ->where('is_verified', true)
            ->take(10)
            ->get()
            ->map(function ($t) {
                return [
                    'id' => $t->id,
                    'name' => $t->user->name,
                    'photo' => $t->photo, // Ensure this exists or handle default
                    'subjects' => $t->subjects,
                    'experience' => $t->experience_years,
                    'qualifications' => $t->qualifications,
                ];
            });

        return response()->json([
            'banners' => $banners,
            'teachers' => $teachers,
        ]);
    }

    public function submitTuitionRequest(Request $request)
    {
        $request->validate([
            'name' => 'required|string',
            'phone' => 'required|string',
            'subject' => 'required|string',
            'grade' => 'required|string',
            'location' => 'required|string',
            'description' => 'nullable|string',
        ]);

        // Create a Lead directly forguest requests
        $lead = \App\Models\Lead::create([
             'tuition_request_id' => null, // No request ID for direct leads yet
             'teacher_id' => null, // General lead
             'status' => 'new',
             'remarks' => "Public Request from {$request->name} ({$request->phone}) for {$request->subject}",
             'is_contact_shared' => false,
        ]);
        
        // Optionally creating a TuitionRequest if user management allows guest/temp users
        // For now, storing as a general System Lead or Admin Notification can handle this.
        
        return response()->json(['message' => 'Request submitted successfully. We will contact you soon.']);
    }
}
