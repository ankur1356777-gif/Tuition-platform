<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Teacher;
use App\Models\User;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function index()
    {
        $stats = [
            'total_teachers' => User::role('teacher')->count(),
            'total_students' => User::role('student')->count(),
            'pending_approvals' => User::pending()->count(),
            'active_tuitions' => \App\Models\PaidTuition::where('status', 'active')->count(),
            'total_revenue' => \App\Models\Transaction::where('type', 'credit')->sum('amount'),
            'pending_payouts' => \App\Models\PayoutRequest::where('status', 'pending')->count(),
            'recent_leads' => \App\Models\Lead::with(['teacher', 'tuitionRequest.student'])->latest()->take(5)->get(),
        ];
        
        return view('admin.dashboard', compact('stats'));
    }

    public function teachers()
    {
        $teachers = User::role('teacher')->with('teacher')->latest()->paginate(10);
        return view('admin.teachers', compact('teachers'));
    }

    public function students()
    {
        $students = User::role('student')->with('student')->latest()->paginate(10);
        return view('admin.students', compact('students'));
    }

    public function leads()
    {
        $leads = \App\Models\Lead::with(['teacher', 'tuitionRequest.student'])->latest()->paginate(20);
        return view('admin.leads', compact('leads'));
    }

    public function payments()
    {
        $payouts = \App\Models\PayoutRequest::with('user')->latest()->paginate(15);
        return view('admin.payments', compact('payouts'));
    }

    public function updatePayoutStatus($id, Request $request)
    {
        $payout = \App\Models\PayoutRequest::findOrFail($id);
        $payout->update(['status' => $request->status]);
        
        // If paid, you might want to deduct from wallet here if not already done
        
        return back()->with('success', 'Payout status updated');
    }

    public function demoClasses()
    {
        $demoClasses = \App\Models\DemoClass::with(['lead.teacher.user', 'lead.tuitionRequest.student.user'])->latest()->paginate(15);
        return view('admin.demo_classes', compact('demoClasses'));
    }

    public function transactions()
    {
        $transactions = \App\Models\Transaction::with('user')->latest()->paginate(20);
        return view('admin.transactions', compact('transactions'));
    }

    public function settings()
    {
        $settings = \App\Models\CommissionSetting::all()->pluck('value', 'key');
        return view('admin.settings', compact('settings'));
    }

    public function updateSettings(Request $request)
    {
        foreach ($request->except('_token') as $key => $value) {
            \App\Models\CommissionSetting::updateOrCreate(
                ['key' => $key],
                ['value' => $value]
            );
        }
        return back()->with('success', 'Settings updated successfully');
    }

    public function agents()
    {
        $agents = User::where('role', 'agent')
            ->with('agent')
            ->latest()
            ->paginate(20);
        
        return view('admin.agents', compact('agents'));
    }

    public function verifyAgent($id, Request $request)
    {
        $user = User::findOrFail($id);
        $user->update(['status' => $request->status]);
        return back()->with('success', 'Agent status updated');
    }

    public function verifyTeacher($id, Request $request)
    {
        $user = User::findOrFail($id);
        $user->update(['status' => $request->status]); // 'approved' or 'rejected'
        return back()->with('success', 'Teacher status updated successfully');
    }

    public function createUser()
    {
        return view('admin.users.create');
    }

    public function storeUser(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'phone' => 'required|string|unique:users,phone',
            'email' => 'nullable|email|unique:users,email',
            'role' => 'required|in:teacher,student,agent',
            'password' => 'required|string|min:6',
        ]);

        $user = User::create([
            'name' => $request->name,
            'phone' => $request->phone,
            'email' => $request->email,
            'password' => \Hash::make($request->password),
            'role' => $request->role,
            'status' => 'approved', 
        ]);

        if ($request->role == 'teacher') {
            Teacher::create(['user_id' => $user->id, 'subjects' => json_encode([]), 'qualifications' => json_encode([]), 'classes' => json_encode([])]);
            \App\Models\Wallet::create(['user_id' => $user->id]);
        } elseif ($request->role == 'student') {
            \App\Models\Student::create(['user_id' => $user->id, 'class' => 'N/A', 'address' => 'N/A', 'latitude' => 0, 'longitude' => 0, 'city' => 'N/A', 'state' => 'N/A', 'pincode' => 'N/A', 'subjects_needed' => json_encode([])]);
        } elseif ($request->role == 'agent') {
            \App\Models\Agent::create(['user_id' => $user->id, 'referral_code' => 'AGT'.strtoupper(substr(uniqid(), -6))]);
        }

        return redirect()->route('admin.' . $request->role . 's')->with('success', 'User created successfully');
    }
}
