<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Teacher;
use App\Models\Student;
use App\Models\TuitionRequest;
use App\Models\Lead;
use App\Models\Transaction;
use App\Models\PayoutRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class AdminApiController extends Controller
{
    public function dashboard()
    {
        return response()->json([
            'stats' => [
                'total_teachers' => User::where('role', 'teacher')->count(),
                'total_students' => User::where('role', 'student')->count(),
                'pending_approvals' => User::where('status', 'pending')->count(),
                'monthly_revenue' => Transaction::where('type', 'commission')->whereMonth('created_at', now()->month)->sum('amount'),
                'active_tuitions' => TuitionRequest::where('status', 'active')->count(),
            ],
            'pending_teachers' => User::where('role', 'teacher')->where('status', 'pending')->limit(5)->get(),
            'recent_leads' => Lead::with(['teacher.user', 'tuitionRequest'])->limit(5)->orderBy('created_at', 'desc')->get()
        ]);
    }

    public function manageUserStatus(Request $request, $id)
    {
        $request->validate([
            'status' => 'required|in:pending,approved,rejected,active,inactive',
        ]);

        $user = User::findOrFail($id);
        $user->status = $request->status;
        $user->save();

        return response()->json([
            'message' => "User status updated to {$request->status}",
            'user' => $user
        ]);
    }

    public function leadsOverview()
    {
        $leads = Lead::with(['teacher.user', 'tuitionRequest.student.user'])->orderBy('created_at', 'desc')->paginate(20);
        return response()->json($leads);
    }

    public function payoutRequests()
    {
        $requests = PayoutRequest::with('user')->where('status', 'pending')->orderBy('created_at', 'asc')->get();
        return response()->json($requests);
    }

    public function approvePayout(Request $request, $id)
    {
        $payout = PayoutRequest::findOrFail($id);
        $payout->status = 'approved';
        $payout->processed_at = now();
        $payout->save();

        return response()->json(['message' => 'Payout approved successfully']);
    }
    // Commission Management
    public function getCommissionSettings()
    {
        return response()->json(\App\Models\CommissionSetting::all());
    }

    public function updateCommissionSettings(Request $request)
    {
        $request->validate([
            'settings' => 'required|array',
            'settings.*.key' => 'required|exists:commission_settings,key',
            'settings.*.value' => 'required|numeric'
        ]);

        foreach ($request->settings as $settingData) {
            \App\Models\CommissionSetting::where('key', $settingData['key'])
                ->update(['value' => $settingData['value']]);
        }

        return response()->json(['message' => 'Commission settings updated successfully']);
    }

    // Teacher Management
    public function getAllTeachers()
    {
        $teachers = Teacher::with('user')->paginate(20);
        return response()->json($teachers);
    }

    public function getTeacherDetails($id)
    {
        $teacher = Teacher::with(['user', 'leads', 'reviews'])->findOrFail($id);
        return response()->json($teacher);
    }
    
    // Student Management
    public function getAllStudents()
    {
        $students = Student::with('user')->paginate(20);
        return response()->json($students);
    }

    public function getStudentDetails($id)
    {
        $student = Student::with(['user', 'tuitionRequests'])->findOrFail($id);
        return response()->json($student);
    }

    // Demo Classes
    public function getAllDemos()
    {
         $demos = \App\Models\DemoClass::with(['lead.teacher.user', 'lead.tuitionRequest.student.user'])
            ->orderBy('created_at', 'desc')
            ->paginate(20);
         return response()->json($demos);
    }

    // Agent Management
    public function getAllAgents()
    {
        $agents = User::where('role', 'agent')->paginate(20);
        return response()->json($agents);
    }
    
    // Attendance Monitoring
    public function getAttendanceLogs(Request $request) 
    {
        $query = \App\Models\Attendance::with(['teacher.user', 'paidTuition.student.user'])
            ->orderBy('marked_at', 'desc');
            
        if ($request->has('teacher_id')) {
            $query->where('teacher_id', $request->teacher_id);
        }
        
        if ($request->has('date')) {
            $query->whereDate('marked_at', $request->date);
        }

        return response()->json($query->paginate(20));
    }
}
