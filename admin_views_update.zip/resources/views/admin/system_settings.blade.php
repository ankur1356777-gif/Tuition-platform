@extends('layouts.admin')

@section('title', 'System Settings')

@section('styles')
<style>
    .settings-tabs {
        display: flex;
        gap: 12px;
        margin-bottom: 24px;
        border-bottom: 2px solid #f1f5f9;
        padding-bottom: 2px;
        overflow-x: auto;
    }

    .tab-link {
        padding: 12px 20px;
        font-weight: 600;
        color: var(--text-muted);
        text-decoration: none;
        white-space: nowrap;
        border-bottom: 2px solid transparent;
        transition: all 0.2s;
        cursor: pointer;
    }

    .tab-link:hover {
        color: var(--primary);
    }

    .tab-link.active {
        color: var(--primary);
        border-bottom-color: var(--primary);
    }

    .tab-content {
        display: none;
    }

    .tab-content.active {
        display: block;
        animation: fadeIn 0.3s;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(5px); }
        to { opacity: 1; transform: translateY(0); }
    }

    .form-group {
        margin-bottom: 24px;
    }

    .form-group label {
        display: block;
        font-size: 14px;
        font-weight: 600;
        margin-bottom: 8px;
        color: var(--text-main);
    }

    .form-control {
        width: 100%;
        padding: 12px 16px;
        border: 1px solid #e2e8f0;
        border-radius: 10px;
        font-size: 14px;
        outline: none;
        transition: border-color 0.2s;
    }

    .form-control:focus {
        border-color: var(--primary);
    }

    .form-text {
        font-size: 12px;
        color: var(--text-muted);
        margin-top: 6px;
    }

    .settings-card {
        max-width: 800px;
    }
</style>
@endsection

@section('content')
<div class="page-header">
    <div>
        <div class="breadcrumb">System / Configuration</div>
        <h1 class="page-title">Global System Settings</h1>
    </div>
</div>

<div class="settings-tabs" id="settingsTabs">
    <div class="tab-link active" onclick="showTab('general')">General</div>
    <div class="tab-link" onclick="showTab('firebase')">Firebase</div>
    <div class="tab-link" onclick="showTab('auth')">Social Auth</div>
    <div class="tab-link" onclick="showTab('smtp')">SMTP Email</div>
    <div class="tab-link" onclick="showTab('payment')">Payment Keys</div>
    <div class="tab-link" onclick="showTab('maintenance')">Maintenance</div>
</div>

<div class="settings-card">
    <!-- General Settings -->
    <div id="general" class="tab-content active">
        <div class="card">
            <h2 style="font-size: 18px; font-weight: 700; margin-bottom: 24px;">Website & App Info</h2>
            <form action="{{ route('admin.system_settings.update') }}" method="POST">
                @csrf
                <input type="hidden" name="group" value="general">
                
                <div class="form-group">
                    <label>App Name</label>
                    <input type="text" name="app_name" class="form-control" value="{{ $settings['general']['app_name'] ?? 'Tuition Platform' }}">
                </div>

                <div class="form-group">
                    <label>Support Phone</label>
                    <input type="text" name="support_phone" class="form-control" value="{{ $settings['general']['support_phone'] ?? '' }}">
                </div>

                <div class="form-group">
                    <label>Support Email</label>
                    <input type="email" name="support_email" class="form-control" value="{{ $settings['general']['support_email'] ?? '' }}">
                </div>

                <button type="submit" class="btn btn-primary">Save General Changes</button>
            </form>
        </div>
    </div>

    <!-- Firebase Settings -->
    <div id="firebase" class="tab-content">
        <div class="card">
            <h2 style="font-size: 18px; font-weight: 700; margin-bottom: 24px;">Firebase & FCM Configuration</h2>
            <form action="{{ route('admin.system_settings.update') }}" method="POST">
                @csrf
                <input type="hidden" name="group" value="firebase">

                <div class="form-group">
                    <label>Firebase Server Key (FCM Legacy)</label>
                    <input type="text" name="fcm_server_key" class="form-control" value="{{ $settings['firebase']['fcm_server_key'] ?? '' }}">
                </div>

                <div class="form-group">
                    <label>Firebase API Key (Web/OTP)</label>
                    <input type="text" name="firebase_api_key" class="form-control" value="{{ $settings['firebase']['firebase_api_key'] ?? '' }}">
                </div>

                <div class="form-group">
                    <label>Firebase Service Account JSON</label>
                    <textarea name="firebase_json" rows="8" class="form-control" placeholder='{"type": "service_account", ...}'>{{ $settings['firebase']['firebase_json'] ?? '' }}</textarea>
                    <p class="form-text">Paste the contents of your Service Account JSON file here for Push Notifications.</p>
                </div>

                <button type="submit" class="btn btn-primary">Update Firebase Config</button>
            </form>
        </div>
    </div>

    <!-- Social Auth -->
    <div id="auth" class="tab-content">
        <div class="card">
            <h2 style="font-size: 18px; font-weight: 700; margin-bottom: 24px;">Google Login Verification</h2>
            <form action="{{ route('admin.system_settings.update') }}" method="POST">
                @csrf
                <input type="hidden" name="group" value="auth">

                <div class="form-group">
                    <label>Google Client ID</label>
                    <input type="text" name="google_client_id" class="form-control" value="{{ $settings['auth']['google_client_id'] ?? '' }}">
                </div>

                <div class="form-group">
                    <label>Google Client Secret</label>
                    <input type="password" name="google_client_secret" class="form-control" value="{{ $settings['auth']['google_client_secret'] ?? '' }}">
                </div>

                <button type="submit" class="btn btn-primary">Save Auth Credentials</button>
            </form>
        </div>
    </div>

    <!-- SMTP Settings -->
    <div id="smtp" class="tab-content">
        <div class="card">
            <h2 style="font-size: 18px; font-weight: 700; margin-bottom: 24px;">SMTP Email Settings</h2>
            <form action="{{ route('admin.system_settings.update') }}" method="POST">
                @csrf
                <input type="hidden" name="group" value="smtp">

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="form-group">
                        <label>SMTP Host</label>
                        <input type="text" name="mail_host" class="form-control" value="{{ $settings['smtp']['mail_host'] ?? '' }}">
                    </div>
                    <div class="form-group">
                        <label>SMTP Port</label>
                        <input type="text" name="mail_port" class="form-control" value="{{ $settings['smtp']['mail_port'] ?? '587' }}">
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" name="mail_username" class="form-control" value="{{ $settings['smtp']['mail_username'] ?? '' }}">
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="mail_password" class="form-control" value="{{ $settings['smtp']['mail_password'] ?? '' }}">
                    </div>
                </div>

                <div class="form-group">
                    <label>Mail Encryption</label>
                    <select name="mail_encryption" class="form-control">
                        <option value="tls" {{ ($settings['smtp']['mail_encryption'] ?? '') == 'tls' ? 'selected' : '' }}>TLS</option>
                        <option value="ssl" {{ ($settings['smtp']['mail_encryption'] ?? '') == 'ssl' ? 'selected' : '' }}>SSL</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary">Save Email Config</button>
            </form>
        </div>
    </div>

    <!-- Payment Settings -->
    <div id="payment" class="tab-content">
        <div class="card">
            <h2 style="font-size: 18px; font-weight: 700; margin-bottom: 24px;">Payment Gateway Keys</h2>
            <form action="{{ route('admin.system_settings.update') }}" method="POST">
                @csrf
                <input type="hidden" name="group" value="payment">

                <div class="nav-category" style="margin: 0 0 16px; color: var(--primary);">Razorpay</div>
                <div class="form-group">
                    <label>Razorpay Key ID</label>
                    <input type="text" name="razorpay_key" class="form-control" value="{{ $settings['payment']['razorpay_key'] ?? '' }}">
                </div>
                <div class="form-group">
                    <label>Razorpay Secret</label>
                    <input type="password" name="razorpay_secret" class="form-control" value="{{ $settings['payment']['razorpay_secret'] ?? '' }}">
                </div>

                <div class="nav-category" style="margin: 24px 0 16px; color: var(--primary);">Stripe (Optional)</div>
                <div class="form-group">
                    <label>Stripe Publishable Key</label>
                    <input type="text" name="stripe_key" class="form-control" value="{{ $settings['payment']['stripe_key'] ?? '' }}">
                </div>
                <div class="form-group">
                    <label>Stripe Secret</label>
                    <input type="password" name="stripe_secret" class="form-control" value="{{ $settings['payment']['stripe_secret'] ?? '' }}">
                </div>

                <button type="submit" class="btn btn-primary">Save Payment Keys</button>
            </form>
        </div>
    </div>

    <!-- Maintenance Mode -->
    <div id="maintenance" class="tab-content">
        <div class="card">
            <h2 style="font-size: 18px; font-weight: 700; margin-bottom: 24px;">App Status & Maintenance</h2>
            <form action="{{ route('admin.system_settings.update') }}" method="POST">
                @csrf
                <input type="hidden" name="group" value="maintenance">

                <div class="form-group">
                    <label>Platform Status</label>
                    <select name="maintenance_mode" class="form-control">
                        <option value="0" {{ ($settings['maintenance']['maintenance_mode'] ?? '0') == '0' ? 'selected' : '' }}>Live (Active)</option>
                        <option value="1" {{ ($settings['maintenance']['maintenance_mode'] ?? '0') == '1' ? 'selected' : '' }}>Maintenance Mode</option>
                    </select>
                    <p class="form-text">When in maintenance mode, users will see a "Service Unavailable" message.</p>
                </div>

                <div class="form-group">
                    <label>Maintenance Message</label>
                    <input type="text" name="maintenance_message" class="form-control" value="{{ $settings['maintenance']['maintenance_message'] ?? 'We are currently performing maintenance. Please check back later.' }}">
                </div>

                <button type="submit" class="btn btn-primary">Apply Status</button>
            </form>
        </div>
    </div>
</div>

@endsection

@section('scripts')
<script>
    function showTab(tabId) {
        // Hide all tab contents
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });

        // Deactivate all tab links
        document.querySelectorAll('.tab-link').forEach(link => {
            link.classList.remove('active');
        });

        // Show selected tab content
        document.getElementById(tabId).classList.add('active');

        // Find the clicking tab and make it active
        const tabsContainer = document.getElementById('settingsTabs');
        const links = tabsContainer.getElementsByClassName('tab-link');
        for (let link of links) {
            if (link.textContent.toLowerCase().includes(tabId)) {
                link.classList.add('active');
            }
        }
    }
</script>
@endsection
