<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PublicController extends Controller
{
    public function getLandingData()
    {
        try {
            $banners = \App\Models\Banner::where('is_active', true)
                ->orderBy('order')
                ->get();
            
            // Publicly visible teachers
            $teachers = \App\Models\Teacher::with('user')
                ->where('is_available', true)
                ->where('is_verified', true)
                ->take(10)
                ->get()
                ->map(function ($t) {
                    $user = $t->user;
                    return [
                        'id' => $t->id,
                        'name' => $user ? $user->name : 'Tutor',
                        'photo' => $user ? ($user->profile_image ?? null) : null,
                        'subjects' => $t->subjects ?? [],
                        'experience' => $t->experience_years ?? 0,
                        'qualifications' => $t->qualifications ?? [],
                    ];
                });

            return response()->json([
                'banners' => $banners,
                'teachers' => $teachers,
            ]);
        } catch (\Exception $e) {
            \Log::error('Landing Data Error: ' . $e->getMessage());
            return response()->json([
                'error' => 'Server Error',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function submitTuitionRequest(Request $request)
    {
        $request->validate([
            'name' => 'required|string',
            'phone' => 'required|string',
            'subject' => 'required|string',
            'grade' => 'required|string',
            'location' => 'required|string',
            'description' => 'nullable|string',
        ]);

        // Create a Lead directly forguest requests
        $lead = \App\Models\Lead::create([
             'tuition_request_id' => null, // No request ID for direct leads yet
             'teacher_id' => null, // General lead
             'status' => 'new',
             'remarks' => "Public Request from {$request->name} ({$request->phone}) for {$request->subject}",
             'is_contact_shared' => false,
        ]);
        
        // Optionally creating a TuitionRequest if user management allows guest/temp users
        // For now, storing as a general System Lead or Admin Notification can handle this.
        
        return response()->json(['message' => 'Request submitted successfully. We will contact you soon.']);
    }
}
