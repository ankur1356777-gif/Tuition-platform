<?php

namespace App\Services;

use App\Models\User;
use App\Models\PaidTuition;
use App\Models\Transaction;
use App\Models\CommissionSetting;
use App\Models\Wallet;
use Illuminate\Support\Facades\DB;

class CommissionService
{
    protected $notificationService;

    public function __construct(NotificationService $notificationService)
    {
        $this->notificationService = $notificationService;
    }

    /**
     * Distribute commission for a new paid tuition
     */
    public function distributeTuitionCommission(PaidTuition $paidTuition)
    {
        DB::beginTransaction();
        try {
            $student = $paidTuition->student->user;
            $agentId = $student->referred_by;
            
            if ($agentId) {
                $agent = User::find($agentId);
                if ($agent && $agent->role === 'agent') {
                    $percentage = CommissionSetting::where('key', 'agent_commission_percentage')->value('value') ?? 10;
                    $amount = ($paidTuition->monthly_fee * $percentage) / 100;

                    // Credit Agent Wallet
                    $wallet = Wallet::firstOrCreate(['user_id' => $agent->id], ['balance' => 0]);
                    $wallet->increment('balance', $amount);

                    // Record Transaction
                    Transaction::create([
                        'user_id' => $agent->id,
                        'amount' => $amount,
                        'type' => 'commission',
                        'status' => 'completed',
                        'description' => "Commission from referral: {$student->name}",
                        'metadata' => ['paid_tuition_id' => $paidTuition->id]
                    ]);

                    // Notify Agent
                    $this->notificationService->sendCommissionCreditedNotification($agent->id, [
                        'amount' => $amount,
                        'student_name' => $student->name
                    ]);
                }
            }

            DB::commit();
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::error('Commission distribution failed: ' . $e->getMessage());
        }
    }
}
