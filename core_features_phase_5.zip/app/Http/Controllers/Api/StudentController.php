<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Student;
use App\Models\TuitionRequest;
use App\Models\Attendance;
use App\Models\TestResult;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class StudentController extends Controller
{
    protected $notificationService;

    public function __construct(\App\Services\NotificationService $notificationService)
    {
        $this->notificationService = $notificationService;
    }

    public function dashboard()
    {
        $user = Auth::user();
        $student = $user->student;

        if (!$student) {
            return response()->json(['message' => 'Student profile not found'], 404);
        }

        return response()->json([
            'stats' => [
                'active_tuitions' => 0, // Logic to be implemented
                'attendance_percentage' => 0, // Logic to be implemented
                'avg_test_score' => TestResult::where('student_id', $student->id)->avg('score') ?? 0,
            ],
            'recent_requests' => TuitionRequest::where('student_id', $student->id)
                ->orderBy('created_at', 'desc')
                ->limit(5)
                ->get()
        ]);
    }

    public function createRequest(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'subject' => 'required|string',
            'grade' => 'required|string',
            'budget' => 'required|numeric',
            'description' => 'nullable|string',
            'preferred_timing' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $tuitionRequest = TuitionRequest::create([
            'student_id' => Auth::user()->student->id,
            'subjects' => is_array($request->subject) ? $request->subject : [$request->subject],
            'class' => $request->grade,
            'budget' => $request->budget,
            'description' => $request->description,
            'preferred_timing' => $request->preferred_timing,
            'status' => 'new',
            'created_at' => now(),
        ]);

        // Trigger matching service to find tutors and create leads
        app(\App\Services\MatchingService::class)->autoMatch($tuitionRequest);

        // Notify student
        $this->notificationService->sendToUser(
            Auth::id(),
            'Tuition Request Submitted',
            'We are matching the best teachers for you. You will be notified soon!',
            'tuition_request_created'
        );

        return response()->json([
            'message' => 'Tuition request created successfully',
            'request' => $tuitionRequest
        ], 201);
    }

    public function viewAttendance()
    {
        $student = Auth::user()->student;
        $attendance = Attendance::whereHas('paidTuition', function($query) use ($student) {
            $query->where('student_id', $student->id);
        })->with('teacher.user')->orderBy('marked_at', 'desc')->get();

        return response()->json($attendance);
    }

    public function viewTestResults()
    {
        $student = Auth::user()->student;
        $results = TestResult::with('test.teacher.user')
            ->where('student_id', $student->id)
            ->orderBy('created_at', 'desc')
            ->get();

        return response()->json($results);
    }

    public function viewPaymentHistory()
    {
        $transactions = \App\Models\Transaction::where('user_id', Auth::id())
            ->orderBy('created_at', 'desc')
            ->get();
        return response()->json($transactions);
    }

    public function submitDemoFeedback(Request $request, $id)
    {
        $request->validate([
            'feedback' => 'required|string',
        ]);

        $studentId = Auth::user()->student->id;

        // Find demo by ID, ensure it belongs to student via Lead -> TuitionRequest
        $demo = \App\Models\DemoClass::whereHas('lead.tuitionRequest', function($q) use ($studentId) {
            $q->where('student_id', $studentId);
        })->find($id);

        if (!$demo) {
            return response()->json(['message' => 'Demo class not found or unauthorized'], 404);
        }

        $demo->feedback = $request->feedback;
        $demo->save();

        return response()->json(['message' => 'Feedback submitted successfully']);
    }
    public function getTests()
    {
        $studentId = Auth::user()->student->id;
        
        // Fetch tests from tuitions the student is enrolled in
        $tests = \App\Models\Test::whereHas('paidTuition', function($q) use ($studentId) {
            $q->where('student_id', $studentId);
        })
        ->with('teacher.user')
        ->where('status', 'scheduled')
        ->orderBy('scheduled_date', 'asc')
        ->get();

        return response()->json($tests);
    }

    public function submitTest(Request $request, $id)
    {
        $request->validate([
            'answers' => 'required|array',
        ]);

        $test = \App\Models\Test::findOrFail($id);
        $studentId = Auth::user()->student->id;

        // Simple MCQ grading
        $score = 0;
        $questions = $test->questions;
        $userAnswers = $request->answers;

        foreach ($questions as $index => $q) {
            if (isset($userAnswers[$index]) && $userAnswers[$index] == $q['correct_option']) {
                $score += $q['marks'] ?? ( $test->total_marks / count($questions) );
            }
        }

        $result = TestResult::create([
            'test_id' => $test->id,
            'student_id' => $studentId,
            'marks_obtained' => $score,
            'remarks' => 'Auto-graded online test',
        ]);

        return response()->json([
            'message' => 'Test submitted successfully',
            'result' => $result
        ]);
    }
    public function getActiveTuitions()
    {
        $studentId = Auth::user()->student->id;
        $activeTuitions = \App\Models\PaidTuition::with(['teacher.user', 'lead.tuitionRequest'])
            ->where('student_id', $studentId)
            ->where('status', 'active')
            ->get();

        return response()->json($activeTuitions);
    }
}
