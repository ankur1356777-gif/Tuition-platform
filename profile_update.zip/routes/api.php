<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

// Authentication Routes
Route::prefix("auth")->group(function () {
    Route::post("/send-otp", [App\Http\Controllers\Api\AuthController::class, "sendOTP"]);
    Route::post("/verify-otp", [App\Http\Controllers\Api\AuthController::class, "verifyOTP"]);
    Route::post("/register", [App\Http\Controllers\Api\AuthController::class, "register"]);
});

// Public Landing Data Routes
Route::prefix("public")->group(function () {
    Route::get("/landing", [App\Http\Controllers\Api\PublicController::class, "getLandingData"]);
    Route::post("/request-tuition", [App\Http\Controllers\Api\PublicController::class, "submitTuitionRequest"]);
    Route::get("/areas", [App\Http\Controllers\Api\PublicController::class, "getAreas"]);
    Route::get("/areas/search", [App\Http\Controllers\Api\AreaController::class, "search"]);
    Route::get("/ping", [App\Http\Controllers\Api\PingController::class, "ping"]);
});

// Protected Routes
Route::middleware("auth:sanctum")->group(function () {
    Route::post("/logout", [App\Http\Controllers\Api\AuthController::class, "logout"]);
    
    Route::prefix("profile")->group(function () {
        Route::get("/", [App\Http\Controllers\Api\ProfileController::class, "show"]);
        Route::post("/", [App\Http\Controllers\Api\ProfileController::class, "update"]);
        Route::post("/teacher", [App\Http\Controllers\Api\ProfileController::class, "updateTeacherProfile"]);
        Route::post("/student", [App\Http\Controllers\Api\ProfileController::class, "updateStudentProfile"]);
    });

    Route::get("/user", function (Request $request) {
        return $request->user();
    });

    // Admin Mobile APIs
    Route::middleware("role:admin")->prefix("admin")->group(function () {
        Route::get("/dashboard", [App\Http\Controllers\Api\AdminApiController::class, "dashboard"]);
        Route::post("/users/{id}/status", [App\Http\Controllers\Api\AdminApiController::class, "manageUserStatus"]);
        Route::get("/leads", [App\Http\Controllers\Api\AdminApiController::class, "leadsOverview"]);
        Route::get("/payouts", [App\Http\Controllers\Api\AdminApiController::class, "payoutRequests"]);
        Route::post("/payouts/{id}/approve", [App\Http\Controllers\Api\AdminApiController::class, "approvePayout"]);

        // Commission Settings
        Route::get("/commission-settings", [App\Http\Controllers\Api\AdminApiController::class, "getCommissionSettings"]);
        Route::post("/commission-settings", [App\Http\Controllers\Api\AdminApiController::class, "updateCommissionSettings"]);
        
        // Extended Management
        Route::get("/teachers", [App\Http\Controllers\Api\AdminApiController::class, "getAllTeachers"]);
        Route::get("/teachers/{id}", [App\Http\Controllers\Api\AdminApiController::class, "getTeacherDetails"]);
        
        Route::get("/students", [App\Http\Controllers\Api\AdminApiController::class, "getAllStudents"]);
        Route::get("/students/{id}", [App\Http\Controllers\Api\AdminApiController::class, "getStudentDetails"]);

        Route::get("/agents", [App\Http\Controllers\Api\AdminApiController::class, "getAllAgents"]);

        Route::get("/demos", [App\Http\Controllers\Api\AdminApiController::class, "getAllDemos"]);
        
        // Monitoring
        Route::get("/attendance-logs", [App\Http\Controllers\Api\AdminApiController::class, "getAttendanceLogs"]);
        
        // Notifications
        Route::post("/notifications/broadcast", [App\Http\Controllers\Api\NotificationController::class, "broadcast"]);
        Route::post("/notifications/send-test", [App\Http\Controllers\Api\NotificationController::class, "sendTest"]);
        
        // Document Verification
        Route::get("/documents/pending", [App\Http\Controllers\Api\DocumentController::class, "pending"]);
        Route::post("/documents/{id}/verify", [App\Http\Controllers\Api\DocumentController::class, "verify"]);

        // Lead Management (Phase 2)
        Route::get("/leads/pending", [App\Http\Controllers\Api\AdminApiController::class, "getPendingLeads"]);
        Route::post("/leads/{id}/approve-contact", [App\Http\Controllers\Api\AdminApiController::class, "approveLeadContact"]);
        Route::post("/leads/{id}/reject-contact", [App\Http\Controllers\Api\AdminApiController::class, "rejectLeadContact"]);
    });

    // Common Protected Routes
    Route::post("/documents/upload", [App\Http\Controllers\Api\DocumentController::class, "upload"]);
    Route::get("/documents", [App\Http\Controllers\Api\DocumentController::class, "index"]);
    
    // Payment Routes
    Route::post("/payments/initiate", [App\Http\Controllers\Api\PaymentController::class, "initiate"]);
    Route::post("/payments/verify", [App\Http\Controllers\Api\PaymentController::class, "verify"]);

    // Teacher APIs
    Route::middleware(["role:teacher", "approved"])->prefix("teacher")->group(function () {
        Route::get("/dashboard", [App\Http\Controllers\Api\TeacherController::class, "dashboard"]);
        Route::get("/leads", [App\Http\Controllers\Api\TeacherController::class, "getLeads"]); // Added
        Route::get("/available-requirements", [App\Http\Controllers\Api\TeacherController::class, "getAvailableRequirements"]);
        Route::post("/requirements/{id}/interest", [App\Http\Controllers\Api\TeacherController::class, "expressInterest"]);
        Route::post("/leads/{id}/manage", [App\Http\Controllers\Api\TeacherController::class, "manageLeads"]);
        Route::post("/attendance", [App\Http\Controllers\Api\TeacherController::class, "markAttendance"]);
        Route::post("/tests", [App\Http\Controllers\Api\TeacherController::class, "createTest"]);
        Route::get("/demos", [App\Http\Controllers\Api\TeacherController::class, "demoClasses"]);
        Route::get("/wallet", [App\Http\Controllers\Api\TeacherController::class, "walletHistory"]);
        Route::post("/leaves", [App\Http\Controllers\Api\TeacherController::class, "applyLeave"]);
        Route::get("/leaves", [App\Http\Controllers\Api\TeacherController::class, "getLeaves"]);
        Route::get("/tuitions", [App\Http\Controllers\Api\TeacherController::class, "getActiveTuitions"]);
        Route::post("/tuition/{id}/meeting", [App\Http\Controllers\Api\TeacherController::class, "updateMeetingId"]);
    });

    // Student/Parent APIs
    Route::middleware(["role:student", "approved"])->prefix("student")->group(function () {
        Route::get("/dashboard", [App\Http\Controllers\Api\StudentController::class, "dashboard"]);
        Route::post("/request", [App\Http\Controllers\Api\StudentController::class, "createRequest"]); // Changed to singular
        Route::get("/attendance", [App\Http\Controllers\Api\StudentController::class, "viewAttendance"]);
        Route::get("/test-results", [App\Http\Controllers\Api\StudentController::class, "viewTestResults"]);
        Route::get("/payments", [App\Http\Controllers\Api\StudentController::class, "viewPaymentHistory"]);
        Route::post("/demos/{id}/feedback", [App\Http\Controllers\Api\StudentController::class, "submitDemoFeedback"]);
        Route::get("/tests", [App\Http\Controllers\Api\StudentController::class, "getTests"]);
        Route::post("/tests/{id}/submit", [App\Http\Controllers\Api\StudentController::class, "submitTest"]);
        Route::get("/tuitions", [App\Http\Controllers\Api\StudentController::class, "getActiveTuitions"]);
    });

    // Agent APIs
    Route::middleware("role:agent")->prefix("agent")->group(function () {
        Route::get("/dashboard", [App\Http\Controllers\Api\AgentController::class, "dashboard"]);
        Route::get("/referrals", [App\Http\Controllers\Api\AgentController::class, "referrals"]);
        Route::get("/wallet", [App\Http\Controllers\Api\AgentController::class, "walletHistory"]);
    });

    // Notifications
    Route::prefix("notifications")->group(function () {
        Route::get("/", [App\Http\Controllers\Api\NotificationController::class, "index"]);
        Route::post("/{id}/read", [App\Http\Controllers\Api\NotificationController::class, "markAsRead"]);
        Route::post("/tokens", [App\Http\Controllers\Api\NotificationController::class, "registerToken"]);
    });
});
