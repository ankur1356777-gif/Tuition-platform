<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Teacher;
use App\Models\Lead;
use App\Models\TuitionRequest;
use App\Models\Attendance;
use App\Models\Test;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class TeacherController extends Controller
{
    protected $notificationService;

    public function __construct(\App\Services\NotificationService $notificationService)
    {
        $this->notificationService = $notificationService;
    }

    public function dashboard()
    {
        $user = Auth::user();
        $teacher = $user->teacher;

        if (!$teacher) {
            return response()->json(['message' => 'Teacher profile not found'], 404);
        }

        return response()->json([
            'stats' => [
                'total_earnings' => $user->wallet ? $user->wallet->balance : 0,
                'active_leads' => Lead::where('teacher_id', $teacher->id)->where('status', 'active')->count(),
                'total_classes' => Attendance::where('teacher_id', $teacher->id)->count(),
                'pending_dues' => 0, // Logic to be implemented
            ],
            'recent_leads' => Lead::with('tuitionRequest')
                ->where('teacher_id', $teacher->id)
                ->orderBy('created_at', 'desc')
                ->limit(5)
                ->get()
        ]);
    }

    public function getLeads()
    {
        $teacherId = Auth::user()->teacher->id;
        $leads = Lead::with('tuitionRequest.student.user')
            ->where('teacher_id', $teacherId)
            ->orderBy('created_at', 'desc')
            ->get();
            
        $formattedLeads = $leads->map(function($lead) {
            $data = $lead->toArray();
            
            if (!$lead->is_contact_shared) {
                if (isset($data['tuition_request']['student']['user'])) {
                    $data['tuition_request']['student']['user']['phone'] = 'HIDDEN';
                }
                if (isset($data['tuition_request']['student'])) {
                    $data['tuition_request']['student']['address'] = 'HIDDEN';
                }
                // Handle guest fields
                $data['tuition_request']['guest_phone'] = 'HIDDEN';
            }
            
            return $data;
        });
            
        return response()->json($formattedLeads);
    }

    public function manageLeads(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'status' => 'required|in:accepted,rejected',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $lead = Lead::findOrFail($id);
        
        if ($lead->teacher_id !== Auth::user()->teacher->id) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        $lead->status = $request->status;
        $lead->save();

        return response()->json([
            'message' => "Lead {$request->status} successfully",
            'lead' => $lead
        ]);
    }

    public function markAttendance(Request $request)
    {
        $request->validate([
            'tuition_id' => 'required|exists:paid_tuitions,id',
            'status' => 'required|in:present,absent',
            'latitude' => 'required',
            'longitude' => 'required',
        ]);

        $attendance = Attendance::create([
            'teacher_id' => Auth::user()->teacher->id,
            'paid_tuition_id' => $request->tuition_id,
            'status' => $request->status,
            'marked_at' => now(),
            'latitude' => $request->latitude,
            'longitude' => $request->longitude,
            'is_verified' => false, // Will be verified by location/student
        ]);

        // Notify Student
        $tuition = \App\Models\PaidTuition::with('student')->find($request->tuition_id);
        if ($tuition && $tuition->student) {
            $this->notificationService->sendAttendanceMarkedNotification(
                $tuition->student->user_id,
                [
                    'status' => $request->status,
                    'date' => now()->format('d M Y'),
                ]
            );
        }

        return response()->json([
            'message' => 'Attendance marked successfully',
            'attendance' => $attendance
        ]);
    }

    public function createTest(Request $request)
    {
        $request->validate([
            'title' => 'required|string',
            'subject' => 'required|string',
            'total_marks' => 'required|integer',
            'tuition_id' => 'required|exists:paid_tuitions,id',
        ]);

        $test = Test::create([
            'teacher_id' => Auth::user()->teacher->id,
            'paid_tuition_id' => $request->tuition_id,
            'title' => $request->title,
            'subject' => $request->subject,
            'total_marks' => $request->total_marks,
            'created_at' => now(),
        ]);

        return response()->json([
            'message' => 'Test created successfully',
            'test' => $test
        ]);
    }

    public function demoClasses()
    {
        $teacherId = Auth::user()->teacher->id;
        
        // Get demos via leads
        $demos = \App\Models\DemoClass::whereHas('lead', function($q) use ($teacherId) {
            $q->where('teacher_id', $teacherId);
        })->with(['lead.tuitionRequest.student.user'])->orderBy('scheduled_at', 'desc')->get();

        $formattedDemos = $demos->map(function($demo) {
            $lead = $demo->lead;
            $student = $lead->tuitionRequest->student;
            $user = $student->user;

            $phone = $lead->is_contact_shared ? ($user->phone ?? 'Unknown') : 'HIDDEN';
            $address = $lead->is_contact_shared ? ($student->address ?? 'N/A') : 'HIDDEN';

            return [
                'id' => $demo->id,
                'status' => $demo->status,
                'scheduled_at' => $demo->scheduled_at,
                'student_name' => $user->name ?? 'Unknown',
                'phone' => $phone,
                'address' => $address,
                'subject' => is_array($lead->tuitionRequest->subjects) 
                    ? implode(', ', $lead->tuitionRequest->subjects) 
                    : $lead->tuitionRequest->subjects,
                'feedback' => $demo->feedback,
                'is_contact_shared' => $lead->is_contact_shared,
            ];
        });

        return response()->json($formattedDemos);
    }

    public function walletHistory()
    {
        $transactions = \App\Models\Transaction::where('user_id', Auth::id())
            ->orderBy('created_at', 'desc')
            ->get();

        return response()->json($transactions);
    }

    // Leave Management
    public function applyLeave(Request $request)
    {
        $request->validate([
            'start_date' => 'required|date|after_or_equal:today',
            'end_date' => 'required|date|after_or_equal:start_date',
            'reason' => 'required|string',
        ]);

        $leave = \App\Models\TeacherLeave::create([
            'teacher_id' => Auth::user()->teacher->id,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date,
            'reason' => $request->reason,
            'status' => 'pending'
        ]);

        return response()->json([
            'message' => 'Leave application submitted successfully',
            'leave' => $leave
        ]);
    }

    public function getLeaves()
    {
        $leaves = \App\Models\TeacherLeave::where('teacher_id', Auth::user()->teacher->id)
            ->orderBy('created_at', 'desc')
            ->get();
            
        return response()->json($leaves);
    }
    public function getActiveTuitions()
    {
        $teacherId = Auth::user()->teacher->id;
        $tuitions = \App\Models\PaidTuition::with(['student.user', 'lead.tuitionRequest'])
            ->where('teacher_id', $teacherId)
            ->where('status', 'active')
            ->get();

        return response()->json($tuitions);
    }

    public function updateMeetingId(Request $request, $id)
    {
        $tuition = \App\Models\PaidTuition::where('teacher_id', Auth::user()->teacher->id)->findOrFail($id);
        $tuition->meeting_id = $request->meeting_id;
        $tuition->save();

        return response()->json(['message' => 'Meeting updated successfully']);
    }
    public function getAvailableRequirements()
    {
        $teacher = Auth::user()->teacher;
        
        if (!$teacher || !$teacher->area_id) {
            return response()->json([]);
        }

        // Fetch requests from the same area that haven't been assigned to this teacher yet
        // and aren't already converted to active tuitions
        $assignedRequestIds = Lead::where('teacher_id', $teacher->id)
            ->pluck('tuition_request_id')
            ->toArray();

        $requirements = TuitionRequest::with(['student.user', 'area'])
            ->where('area_id', $teacher->area_id)
            ->whereNotIn('id', $assignedRequestIds)
            ->where('status', 'new')
            ->orderBy('created_at', 'desc')
            ->get();

        $formatted = $requirements->map(function($req) {
            return [
                'id' => $req->id,
                'student_name' => $req->guest_name ?? ($req->student->user->name ?? 'Student'),
                'class' => $req->class,
                'subjects' => is_string($req->subjects) ? json_decode($req->subjects, true) : $req->subjects,
                'budget' => $req->budget,
                'location' => $req->location,
                'area_name' => $req->area ? $req->area->name : 'Lucknow',
                'created_at' => $req->created_at,
            ];
        });

        return response()->json($formatted);
    }

    public function expressInterest($id)
    {
        $teacher = Auth::user()->teacher;
        $tuitionRequest = TuitionRequest::findOrFail($id);

        // Check if lead already exists for this teacher and request
        $existingLead = Lead::where('teacher_id', $teacher->id)
            ->where('tuition_request_id', $tuitionRequest->id)
            ->first();

        if ($existingLead) {
            return response()->json(['message' => 'You have already expressed interest in this requirement.'], 400);
        }

        // Create a lead with status 'pending_approval'
        $lead = Lead::create([
            'teacher_id' => $teacher->id,
            'tuition_request_id' => $tuitionRequest->id,
            'status' => 'pending_approval',
            'is_contact_shared' => false,
            'sent_at' => now(),
            'expires_at' => now()->addDays(7),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Interest expressed successfully. Admin will review and share contact details shortly.',
            'lead' => $lead
        ]);
    }
}
